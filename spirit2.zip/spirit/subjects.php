<?php
$subjects_frontend = array( "Java Script","AngularJs","Angular","React","Redux","Vue", "NodeJs", "Mongo Db", "HTML", "CSS", "jQuery", "Typescript");
$subjects = array( "Core Java", "Hybernate", "Spring Boot", "PHP", "Laravel", "OOP", "Web Security", "Web Socket", "DevOps", "Jenkins", "CI/CD", "Pipelines", "AWS", "React Native", "Phone Gap", "Cordova", "SVN", "GIT");

?>