<?php 
include_once("db_connect.php");
print_r($_REQUEST);
if(isset($_GET["order"])) {
	$order  = explode(",",$_GET["order"]);
	for($i=0; $i < count($order);$i++) {
		$sql = "UPDATE qa SET order_by='" . $i . "' WHERE id=". $order[$i];
		//echo $sql;	
		mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));	
	}
}

?>