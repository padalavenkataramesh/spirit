<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>My spirit</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>

<body>
<?php
// Include config file
require_once "../config.php";
require_once "../subjects.php";
// Attempt select query execution

$sql = "SELECT * FROM qa  ORDER BY order_by ASC";
?>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading" data-toggle="modal" data-target="#myModal" style="cursor:pointer">Your self</div>
      <div class="list-group list-group-flush">
        <?php for ($x = 0; $x < count($subjects); $x++) { ?>
        <a href="#" class="list-group-item list-group-item-action bg-light"  onClick="loadQuestions('<?php echo str_replace(' ', '-', strtolower($subjects[$x])); ?>')"><?php echo $subjects[$x]; ?></a>
        <?php } ?>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <!-- <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button> -->
            <div id="menu-toggle">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>
            </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <?php for ($x = 0; $x < count($subjects_frontend); $x++) { ?>
            <li class="nav-item">
              <a class="nav-link nav-<?php echo str_replace(' ', '-', strtolower($subjects_frontend[$x])); ?>"  style="cursor:pointer" onClick="loadQuestions('<?php echo str_replace(' ', '-', strtolower($subjects_frontend[$x])); ?>')"><?php echo $subjects_frontend[$x]; ?></a>
            </li>
          <?php } ?>
            
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Dropdown
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">


        <!-- externl stuff -->
        <div class="px-3 py-3">
            <?php 
            if($result = mysqli_query($link, $sql)){
                while($row = mysqli_fetch_array($result)){
                    // $subject = "Dashboard";
            ?>
          <div class="topic-chip-container questions questions-<?php echo $row['subject']; ?>"> 
          <a class="no-link" title="Interview Answers"
              alt="Interview Answers">
              <div class="closebtn cls-<?php echo $row['id'];?>" onClick="closeDescription('<?php echo $row['id'];?>')" >&#10005;</div>

              <div class="topic-chip hovered" onClick="showDescription('<?php echo $row['id'];?>')">
                <div class="justify-content-center align-self-center">
                  <span ><b>&nbsp;&nbsp;<?php echo $row['question']; ?></b></span>
                  <!-- <span
                    class="small text-muted">&nbsp;&nbsp;45&nbsp;&nbsp;</span> -->
                </div>
              </div>
            </a>
        </div>
            <div class="answers answer-<?php echo $row['id'];?>" ><b>&nbsp;&nbsp;<?php echo $row['description']; ?></b></div>
            <?php } } ?>
         
        </div>
        <!-- external stuff -->

      </div>
      <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
  
  

<!-- Modal -->
<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button> -->
 <div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
  
    <div class="modal-content">
      <div class="modal-header">
          Your self
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <p>Hi, <br><br> I’m a project leader with over ten years of experience specializing in service & product based unique website experiences. I’m looking forward to growing my management skills to hopefully develop and inspire a team of my own. <br>
I’ve recently Developed DTCC project which is having VUE js & Micro services on project modules
<br>
My skill sets are Vue, React, Angular & Spring boot, HTML, CSS, JQuery, PHP
<br><br>
Comming to the my education i have completed MCA 2009 at Andra Usersity.
</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    
  </div>
</div>
<!-- end Modal -->
  </div>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function (e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    function loadQuestions(val) {
        // alert(val)
        $(".answers").hide();
        $(".questions").hide();
        $(".questions-"+val).show(200);

        //apply active class
        $(".nav-link").removeClass('active');
        $(".nav-"+val).addClass('active');
    }
    function showDescription(val) {
        $(".answers").hide();
        $(".closebtn").hide();
        $(".answer-"+val).show(200);
        $(".cls-"+val).show(200);
        
    }
    function closeDescription(val) {
        $(".answers").hide();
        $(".closebtn").hide();
        $(".cls-"+val).hide(200);
    }
  </script>

</body>

</html>
<style>
  .topic-chip-container {
    display: inline-flex;
    flex-direction: row;
  }

  .topic-chip,
  .topic-chip-selected {
    display: inline-flex;
    flex-direction: row;
    border: none;
    cursor: pointer;
    height: 34px;
    outline: none;
    padding-left: 10px;
    padding-right: 10px;
    font-size: 14px;
    color: #333;
    white-space: nowrap;
    align-items: center;
    border-radius: 20px;
    vertical-align: middle;
    text-decoration: none;
    justify-content: center;
    box-shadow: 0 2px 1px -1px #d3d3d3;
  }

  .topic-chip {
    margin-bottom: 5px;
    margin-top: 5px;
    margin-right: 7px;
    background-color: #e5e5e5;
  }

  .hovered {
    transition: .3s;
  }
  .answers {
      display:none;
      font-size:12px;
      font-weight: 300;
  }
  .list-group-item {
    padding: 0.25rem .75rem;
  }
  .navbar {
    /* padding: .5rem 1rem; */
    padding: 2px;
    }
    .navbar-expand-lg .navbar-nav .nav-link {
        padding-right: 0.4rem;
        padding-left: .4rem;
    }
    .closebtn {
        display:none;
        float:right;
        cursor:pointer;
        color: red;
        font-size: 0.9rem;
    }
    
    /* toogle menu */

#menu-toggle {
    width: 33px;
    /* height: 30px; */
    /* margin: 0px auto; */
    background: #ccc;
}

#menu-toggle div {
  width: 100%;
  height: 5px;
  background: white;
  margin: 4px auto;
  transition: all 0.3s;
  backface-visibility: hidden;
}

#menu-toggle.on .one {
  transform: rotate(45deg) translate(5px, 5px);
}

#menu-toggle.on .two {
  opacity: 0;
}

#menu-toggle.on .three {
  transform: rotate(-45deg) translate(7px, -8px);
}

/* toggle menu end */
</style>