<?php
// Include config file
require_once "config.php";
require_once "subjects.php";

// Define variables and initialize with empty values
$subject = $question = $description = $metainfo = "";
$subject_err = $question_err = $description_err = $metainfo_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate subject
    $input_subject = trim($_POST["subject"]);
    if(empty($input_subject)){
        $subject_err = "Please enter a subject.";
    // } elseif(!filter_var($input_subject, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        // $subject_err = "Please enter a valid subject.";
    } else{
        $subject = $input_subject;
    }

    // Validate question
    $input_question = trim($_POST["question"]);
    if(empty($input_question)){
        $question_err = "Please enter a question.";
    // } elseif(!filter_var($input_question, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        // $question_err = "Please enter a valid question.";
    } else{
        $question = $input_question;
    }
    
    // Validate description
    $input_description = trim($_POST["description"]);
    if(empty($input_description)){
        $description_err = "Please enter an description.";     
    } else{
        $description = $input_description;
    }
    
    // Validate metainfo
    $input_metainfo = trim($_POST["metainfo"]);
    // if(empty($input_metainfo)){
    //     $metainfo_err = "Please enter the metainfo.";     
    // // } elseif(!ctype_digit($input_metainfo)){
    // // $metainfo_err = "Please enter a positive integer value.";
    // } else{
    //     $metainfo = $input_metainfo;
    // }
    $metainfo = $input_metainfo;
    
    // Check input errors before inserting in database
    if(empty($subject_err) && empty($question_err) && empty($description_err) && empty($metainfo_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO qa (subject, question, description, metainfo) VALUES (?, ?, ?, ?)";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_subject, $param_question, $param_description, $param_metainfo);
            
            // Set parameters
            $param_subject = $subject;
            $param_question = $question;
            $param_description = $description;
            $param_metainfo = $metainfo;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
        
            // //  $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            // if ($link->connect_error) {
            //    die("Connection failed: " . $link->connect_error);
            // } 
            // $sql = "INSERT INTO qa(question, description, metainfo)VALUES ('".$question."','".$description."','".$metainfo."')";

            // if (mysqli_query($link, $sql)) {
            //     header("location: index.php");
            //     exit();
            // } else {
            //    echo "Error: " . $sql . "" . mysqli_error($link);
            // }
            // $link->close();
       
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="ckeditor/ckeditor.js"></script>
    <style type="text/css">
        .wrapper{
            width: 800px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h3>Create QA</h3>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($subject_err)) ? 'has-error' : ''; ?>">
                            <label>Subject</label>
                            <!-- <input type="text" name="subject" class="form-control" value="<?php echo $subject; ?>"> -->
                            <select name="subject" class="form-control">
                                <option value="">--Select Subject--</option>
                                <?php for ($x = 0; $x < count($subjects_frontend); $x++) { ?>
                                <option value="<?php echo str_replace(' ', '-', strtolower($subjects_frontend[$x])); ?>"><?php echo $subjects_frontend[$x]; ?></option>
                                <?php } ?>
                                <?php for ($x = 0; $x < count($subjects); $x++) { ?>
                                <option value="<?php echo str_replace(' ', '-', strtolower($subjects[$x])); ?>"><?php echo $subjects[$x]; ?></option>
                                <?php } ?>
                            </select>
                            <span class="help-block"><?php echo $subject_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($question_err)) ? 'has-error' : ''; ?>">
                            <label>Question</label>
                            <input type="text" name="question" class="form-control" value="<?php echo $question; ?>">
                            <span class="help-block"><?php echo $question_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
                            <label>Description</label>
                            <!-- <textarea name="description" class="form-control"><?php //echo $description; ?></textarea> -->
                            <textarea class="ckeditor" name="description"><?php echo $description; ?></textarea>
                            <span class="help-block"><?php echo $description_err;?></span>
                            
                        </div>
                        <div class="form-group <?php echo (!empty($metainfo_err)) ? 'has-error' : ''; ?>">
                            <label>Meta Info</label>
                            <input type="text" name="metainfo" class="form-control" value="<?php echo $metainfo; ?>">
                            <span class="help-block"><?php echo $metainfo_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>