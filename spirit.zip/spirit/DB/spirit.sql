-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2021 at 05:35 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spirit`
--

-- --------------------------------------------------------

--
-- Table structure for table `qa`
--

CREATE TABLE `qa` (
  `id` int(11) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `question` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `metainfo` text NOT NULL,
  `order_by` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qa`
--

INSERT INTO `qa` (`id`, `subject`, `question`, `description`, `metainfo`, `order_by`) VALUES
(1, 'java-script', 'about', '<p>Developed by Brendan Eich in 1995, JavaScript is one of the most popular languages for web development.<br />\r\nIt was initially created to develop dynamic web pages. Every JS program is called a script, which can be attached to any web page&rsquo;s HTML. These scripts run automatically when the page loads.<br />\r\nA language which was initially used to create dynamic web pages, can now be executed on the server and practically on any device consisting of the JavaScript Engine</p>', '', 15),
(2, 'java-script', 'data types', '<h2 style=\"font-style:italic\"><strong>Primitive types</strong></h2>\r\n\r\n<ul>\r\n	<li><strong>String&nbsp;</strong>- It represents a series of characters and is written with quotes. A string can be represented using a single or a double quote.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\n var str = &quot;Vivek Singh Bisht&quot;; //using double quotes\r\n var str2 = &#39;John Doe&#39;; //using single quotes\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>Number&nbsp;</strong>- It represents a number and can be written with or without decimals.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar x = 3; //without decimal\r\nvar y = 3.6; //with decimal\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>BigInt&nbsp;</strong>- This data type is used to store numbers which are above the limitation of the Number data type. It can store large integers and is represented by adding &ldquo;n&rdquo; to an integer literal.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar bigInteger =  234567890123456789012345678901234567890;\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>Boolean&nbsp;</strong>- It represents a logical entity and can have only two values : true or false. Booleans are generally used for conditional testing.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar a = 2;\r\nvar b =  3;\r\nvar c =  2;\r\n(a == b) // returns false\r\n(a == c) //returns true\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>Undefined&nbsp;</strong>- When a variable is declared but not assigned, it has the value of undefined and it&rsquo;s type is also undefined.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar x; // value of x is undefined\r\nvar y = undefined; // we can also set the value of a variable as undefined\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>Null&nbsp;</strong>- It represents a non-existent or a invalid value.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar z = null;\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><strong>Symbol&nbsp;</strong>- It is a new data type introduced in the ES6 version of javascript. It is used to store an anonymous and unique value.</li>\r\n</ul>\r\n\r\n<p>Example :</p>\r\n\r\n<pre>\r\nvar symbol1 = Symbol(&#39;symbol&#39;);\r\n\r\n</pre>\r\n\r\n<ul>\r\n	<li><samp>typeof&nbsp;</samp><strong>of primitive types&nbsp;</strong>:</li>\r\n</ul>\r\n\r\n<pre>\r\ntypeof &quot;John Doe&quot; // Returns &quot;string&quot;\r\ntypeof 3.14 // Returns &quot;number&quot;\r\ntypeof true // Returns &quot;boolean&quot;\r\ntypeof 234567890123456789012345678901234567890n // Returns bigint\r\ntypeof undefined // Returns &quot;undefined&quot;\r\ntypeof null // Returns &quot;object&quot; (kind of a bug in JavaScript)\r\ntypeof Symbol(&#39;symbol&#39;) // Returns Symbol\r\n</pre>\r\n\r\n<h2 style=\"font-style:italic\"><br />\r\n<strong>Non-primitive types</strong></h2>\r\n\r\n<p>Primitive&nbsp;data&nbsp;types&nbsp;can&nbsp;store&nbsp;only&nbsp;a&nbsp;single&nbsp;value.&nbsp;To&nbsp;store&nbsp;multiple&nbsp;and&nbsp;complex&nbsp;values,&nbsp;non-primitive&nbsp;data&nbsp;types&nbsp;are&nbsp;used.</p>\r\n\r\n<p>Object&nbsp;-&nbsp;Used&nbsp;to&nbsp;store&nbsp;collection&nbsp;of&nbsp;data</p>\r\n\r\n<h2 style=\"font-style:italic\">Example:</h2>\r\n\r\n<pre>\r\n// Collection of data in key-value pairs\r\n\r\nvar obj1 = {\r\n   x:  43,\r\n   y:  &quot;Hello world!&quot;,\r\n   z: function(){\r\n      return this.x;\r\n   }\r\n}\r\n\r\n// Collection of data as an ordered list\r\n      \r\nvar array1 = [5, &quot;Hello&quot;, true, 4.1];   \r\n</pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>*Note- It is important to remember that any data type that is not primitive data type, is of Object type in javascript.</p>', '', 16),
(3, 'java-script', 'features', '<p>Following are the&nbsp;<strong>features</strong>&nbsp;of JavaScript:</p>\r\n\r\n<ul>\r\n	<li>It is a&nbsp;<strong>lightweight, interpreted</strong>&nbsp;programming language.</li>\r\n	<li>It is designed for creating&nbsp;<strong>network-centric</strong>&nbsp;applications.</li>\r\n	<li>It&nbsp;is complementary to and&nbsp;<strong>integrated</strong>&nbsp;with Java.</li>\r\n	<li>It is an&nbsp;<strong>open</strong>&nbsp;and&nbsp;<strong>cross-platform</strong>&nbsp;scripting language.</li>\r\n</ul>\r\n\r\n<p><img alt=\"Features - JavaScript Interview Questions\" src=\"https://d1jnx9ba8s6j9r.cloudfront.net/blog/wp-content/uploads/2019/01/3-528x179.png\" /></p>', '', 10),
(4, 'java-script', 'is case-sensitive?', '<p>Yes, JavaScript is a<strong>&nbsp;case sensitive</strong>&nbsp;language.&nbsp; The language keywords, variables, function names, and any other identifiers must always be typed with a consistent capitalization of letters.</p>', '', 9),
(5, 'java-script', 'advantages', '<p><img alt=\"JavaScript advantages - JavaScript interview questions\" src=\"https://d1jnx9ba8s6j9r.cloudfront.net/blog/wp-content/uploads/2019/01/2.png\" style=\"width:500px\" /></p>\r\n\r\n<p>Following are the&nbsp;<strong>advantages</strong>&nbsp;of using JavaScript &minus;</p>\r\n\r\n<ul>\r\n	<li><strong>Less server interaction</strong>&nbsp;&minus; You can validate user input before sending the page off to the server. This saves server traffic, which means less load on your server.</li>\r\n	<li><strong>Immediate feedback to the visitors</strong>&nbsp;&minus; They don&rsquo;t have to wait for a page reload to see if they have forgotten to enter something.</li>\r\n	<li><strong>Increased interactivity</strong>&nbsp;&minus; You can create interfaces that react when the user hovers over them with a mouse or activates them via the keyboard.</li>\r\n	<li><strong>Richer interfaces</strong>&nbsp;&minus; You can use JavaScript to include such items as drag-and-drop components and sliders to give a Rich Interface to your site visitors.</li>\r\n</ul>', '', 4),
(6, 'java-script', 'create an object', '<p>JavaScript supports&nbsp;<strong>Object</strong>&nbsp;concept very well. You can create an object using the&nbsp;<strong>object literal</strong>&nbsp;as follows &minus;</p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p><code>var emp = {</code></p>\r\n\r\n			<p><code>name: &quot;Daniel&quot;,age: 23</code></p>\r\n\r\n			<p><code>};</code></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '', 11),
(7, 'java-script', 'create an Array', '<p>You can define arrays using the&nbsp;<strong>array literal</strong>&nbsp;as follows-</p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><code>var x = [];</code></p>\r\n\r\n			<p><code>var y = [1, 2, 3, 4, 5];</code></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '', 0),
(8, 'java-script', 'scopes of a variable', '<p>The scope of a variable is the&nbsp;<strong>region</strong>&nbsp;of your program in which it is&nbsp;<strong>defined</strong>. JavaScript variable will have only two scopes.<br />\r\n&bull;&nbsp;<strong>Global Variables</strong>&nbsp;&minus; A global variable has global scope which means it is visible everywhere in your JavaScript code.<br />\r\n&bull;<strong>&nbsp;Local Variables</strong>&nbsp;&minus; A local variable will be visible only within a function where it is defined. Function parameters are always local to that function.</p>', '', 14),
(9, 'java-script', 'purpose of â€˜Thisâ€™', '<p>The JavaScript&nbsp;<strong>this</strong>&nbsp;keyword refers to the object it belongs to. This has different values depending on where it is used. In a method, this refers to the owner object and in a function, this refers to the global object.</p>', '', 8),
(10, 'java-script', 'Callback', '<p>A&nbsp;<strong>callback</strong>&nbsp;is a plain JavaScript function passed to some method as an argument or option. It&nbsp;is a function that is to be&nbsp;<strong>executed</strong>&nbsp;after another function has finished executing, hence the name &lsquo;<strong>call back</strong>&lsquo;. In&nbsp;JavaScript, functions are objects. Because of this, functions can take functions as arguments, and can be returned by other functions.<br />\r\n<img alt=\"CallBack - JavaScript interview questions\" src=\"https://d1jnx9ba8s6j9r.cloudfront.net/blog/wp-content/uploads/2019/01/CallBack-150x150.jpg\" /></p>', '', 6),
(11, 'java-script', 'Closure', '<p><strong>Closures</strong>&nbsp;are created whenever a variable that is defined outside the&nbsp;<strong>current scope</strong>&nbsp;is accessed from within some inner scope. It gives you access to an outer function&rsquo;s scope from an inner function. In JavaScript, closures are created every time a function is created. To use a closure, simply define a function inside another function and expose it.</p>', '', 5),
(12, 'java-script', 'built-in methods', '<table border=\"1\">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>Built-in Method</strong></td>\r\n			<td><strong>Values</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>CharAt()</strong></td>\r\n			<td>It returns the character at the specified index.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Concat()</strong></td>\r\n			<td>It joins two or more strings.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>forEach()</strong></td>\r\n			<td>It calls a function for each element in the array.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>indexOf()</strong></td>\r\n			<td>It returns the index within the calling String object of the first occurrence of the specified value.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>length()</strong></td>\r\n			<td>It returns the length of the string.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>pop()</strong></td>\r\n			<td>It removes the last element from an array and returns that element.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>push()</strong></td>\r\n			<td>It adds one or more elements to the end of an array and returns the new length of the array.</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>reverse()</strong></td>\r\n			<td>It reverses the order of the elements of an array.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '', 1),
(13, 'java-script', 'naming conventions', '<p>The following&nbsp;<strong>rules</strong>&nbsp;are to be followed while&nbsp;<strong>naming variables</strong>&nbsp;in JavaScript:</p>\r\n\r\n<ol>\r\n	<li>You should not use any of the JavaScript&nbsp;<strong>reserved keyword</strong>&nbsp;as variable name. For example, break or boolean variable names are not valid.</li>\r\n	<li>JavaScript variable names should not start with a&nbsp;<strong>numeral</strong>&nbsp;(0-9). They must begin with a letter or the underscore character. For example, 123name is an invalid variable name but _123name or name123 is a valid one.</li>\r\n	<li>JavaScript variable names are&nbsp;<strong>case sensitive</strong>. For example, Test and test are two different variables.</li>\r\n</ol>', 'naming conventions', 13),
(14, 'java-script', 'TypeOf Operator', '<p>The&nbsp;<strong>typeof</strong>&nbsp;operator is used to get the data type of its operand. The operand can be either a&nbsp;<strong>literal</strong>&nbsp;or a&nbsp;<strong>data structure</strong>&nbsp;such as a variable, a function, or an object. It is a&nbsp;<strong>unary</strong>&nbsp;operator that is placed before its single operand, which can be of any type. Its value is a string indicating the data type of the operand.</p>', 'TypeOf Operator', 3),
(15, 'java-script', 'cookie', '<p>The simplest way to create a cookie is to assign a string value to the&nbsp;<strong>document.cookie</strong>&nbsp;object, which looks like this-</p>\r\n\r\n<p><strong>Syntax :</strong></p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><code>document.cookie = &quot;key1 = value1; key2 = value2; expires = date&quot;;</code></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>How to read a cookie using JavaScript?</strong></h3>\r\n\r\n<p>Reading a cookie is just as simple as writing one, because the value of the document.cookie object is the cookie. So you can use this string whenever you want to access the cookie.<a name=\"inter\"></a></p>\r\n\r\n<ul>\r\n	<li>The&nbsp;<strong>document.cookie</strong>&nbsp;string will keep a list of name = value pairs separated by semicolons, where name is the name of a cookie and value is its string value.</li>\r\n	<li>You can use strings&rsquo;&nbsp;<strong>split()</strong>&nbsp;function to break the string into key and values.</li>\r\n</ul>\r\n\r\n<h3><strong>How to delete a cookie using JavaScript?</strong></h3>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>If you want to delete a cookie so that subsequent attempts to read the cookie return nothing, you just need to set the expiration date to a time in the past.&nbsp;You should define the cookie path to ensure that you delete the right cookie. Some browsers will not let you delete a cookie if you don&rsquo;t specify the path.</p>', 'cookie', 7),
(16, 'java-script', 'Attributes & Property', '<p><strong>Attributes-</strong>&nbsp;&nbsp;provide more details on an element like id, type, value etc.</p>\r\n\r\n<p><strong>Property-</strong>&nbsp;&nbsp;is the value assigned to the property like type=&rdquo;text&rdquo;, value=&rsquo;Name&rsquo; etc.</p>', 'Attributes & Property', 17),
(17, 'java-script', 'accessed HTML element different ways?', '<p>(i)&nbsp;<strong>getElementById(&lsquo;idname&rsquo;):</strong>&nbsp;Gets an element by its ID name<br />\r\n(ii)&nbsp;<strong>getElementsByClass(&lsquo;classname&rsquo;):</strong>&nbsp;Gets all the elements that have the given classname.<br />\r\n(iii)&nbsp;<strong>getElementsByTagName(&lsquo;tagname&rsquo;):</strong>&nbsp;Gets all the elements that have the given tag name.<br />\r\n(iv)&nbsp;<strong>querySelector():</strong>&nbsp;This function takes css style selector and returns the first selected element.</p>', 'List out the different ways an HTML element can be accessed in a JavaScript code.', 2),
(18, 'java-script', 'how many ways a JS code involved in an HTML file?', '<p>There are 3 different ways in which a JavaScript code can be involved in an HTML file:</p>\r\n\r\n<ul>\r\n	<li><strong>Inline</strong></li>\r\n	<li><strong>Internal</strong></li>\r\n	<li><strong>External</strong></li>\r\n</ul>', 'In how many ways a JavaScript code can be involved in an HTML file?', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `qa`
--
ALTER TABLE `qa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `qa`
--
ALTER TABLE `qa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
