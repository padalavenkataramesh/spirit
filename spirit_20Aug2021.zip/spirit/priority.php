<?php
$priorityAr = array( "Basic","Advanced","Repeated","Difference","Exercise");

?>