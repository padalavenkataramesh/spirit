<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>My spirit</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>

<body>
<?php
// Include config file
require_once "../config.php";
require_once "../subjects.php";

// Attempt select query execution

$sql = "SELECT * FROM qa ORDER BY FIELD(priority, 'basic', 'advanced', 'repeated'), order_by ASC";
?>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading" data-toggle="modal" data-target="#myModal" style="cursor:pointer">Your self</div>
      <div class="list-group list-group-flush">
        <?php for ($x = 0; $x < count($subjects); $x++) { ?>
        <a href="#" class="list-group-item list-group-item-action bg-light"  onClick="loadQuestions('<?php echo str_replace(' ', '-', strtolower($subjects[$x])); ?>')"><?php echo $subjects[$x]; ?></a>
        <?php } ?>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <!-- <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button> -->
            <div id="menu-toggle">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>
            </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="input-group" style="width: 375px;padding-left: 20px;">
        <a class="text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" onClick="speekForSearch()" class="speeker" title="speek for search" fill="currentColor" class="bi bi-mic" viewBox="0 0 16 16">
        <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/>
        <path d="M10 8a2 2 0 1 1-4 0V3a2 2 0 1 1 4 0v5zM8 0a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V3a3 3 0 0 0-3-3z"/>
        </svg>

          <span class="action_output" style="display:none">&nbsp;
          <span id="action"></span>
          <span id="output" class="hide"></span>
          &nbsp;
          </span>
              </a>
        <input type="search" class="form-control rounded searchbox" placeholder="Search" aria-label="Search"
        aria-describedby="search-addon" title="enter for search" onkeypress="handle(event)" />
        <input type="hidden" id="subject-link" value="java-script"/>
        &nbsp;<button type="button" class="btn btn-outline-primary searchbtn" onClick="callSearch()" title="search" >Search</button>
        &nbsp;<button type="button" class="btn btn-outline-primary" onClick="callReset()" title="reset search">Reset</button>
        </div>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <?php for ($x = 0; $x < count($subjects_frontend); $x++) { ?>
            <li class="nav-item">
              <a class="nav-link nav-<?php echo str_replace(' ', '-', strtolower($subjects_frontend[$x])); ?>"  style="cursor:pointer" onClick="loadQuestions('<?php echo str_replace(' ', '-', strtolower($subjects_frontend[$x])); ?>')"><?php echo $subjects_frontend[$x]; ?></a>
            </li>
          <?php } ?>
            
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Dropdown
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
          
      <div class="container-fluid-ajax" style="border:1px solid green;"></div>
      <div class="container-fluid" style="border:1px solid red;">


        <!-- externl stuff -->
        <div class="px-3 py-3">
            <?php 
			$priorityArr= [];
            if($result = mysqli_query($link, $sql)){
                while($row = mysqli_fetch_array($result)){
                    // $subject = "Dashboard";
            ?>
		 <?php 
		 if (!in_array($row['priority'], $priorityArr)) {
		?>
		 <div class="header-priority"><h5> <?php  echo ucfirst($row['priority']); ?></h5></div>
		 <?php
			$priorityArr[] = $row['priority'];
		 }
		 ?>
          <div class="topic-chip-container questions questions-<?php echo $row['subject']; ?>"> 
          <a class="no-link" title="<?php echo $row['metainfo'] ? $row['metainfo'] : $row['question']; ?>"
              alt="<?php echo $row['question']; ?>">
              <div class="closebtn cls-<?php echo $row['id'];?>" onClick="closeDescription('<?php echo $row['id'];?>')" >&#10005;</div>

              <div class="topic-chip hovered" onClick="showDescription('<?php echo $row['id'];?>')">
                <div class="justify-content-center align-self-center">
                  <span >&nbsp;&nbsp;<?php echo $row['question']; ?></span>
                  <!-- <span
                    class="small text-muted">&nbsp;&nbsp;45&nbsp;&nbsp;</span> -->
                </div>
              </div>
            </a>
        </div>
            <div class="answers answer-<?php echo $row['id'];?>" ><b>&nbsp;&nbsp;<?php echo $row['description']; ?></b></div>
            <?php } } ?>
         
        </div>
        <!-- external stuff -->

      </div>
      <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
  
  

<!-- Modal -->
<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button> -->
 <div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
  
    <div class="modal-content">
      <div class="modal-header">
          Your self
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <p>Hi, <br><br> I’m a project leader with over ten years of experience specializing in service & product based unique website experiences. I’m looking forward to growing my management skills to hopefully develop and inspire a team of my own. <br>
I’ve recently Developed DTCC project which is having VUE js & Micro services on project modules
<br>
My skill sets are Vue, React, Angular & Spring boot, HTML, CSS, JQuery, PHP
<br><br>
Comming to the my education i have completed MCA 2009 at Andra Usersity.
</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    
  </div>
</div>
<!-- end Modal -->
  </div>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function (e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    function loadQuestions(val) {
        callReset();
        $("#subject-link").val(val);
        $(".answers").hide();
        // alert(val)
        $(".answers").hide();
        $(".questions").hide();
        $(".questions-"+val).show(200);

        //apply active class
        $(".nav-link").removeClass('active');
        $(".nav-"+val).addClass('active');
    }
    function showDescription(val) {
        $(".answers").hide();
        $(".closebtn").hide();
        $(".answer-"+val).show(200);
        $(".cls-"+val).show(200);
        
    }
    function closeDescription(val) {
        $(".answers").hide();
        $(".closebtn").hide();
        $(".cls-"+val).hide(200);
    }
    function handle(e){
        if(e.keyCode === 13){
            e.preventDefault(); // Ensure it is only this code that runs
            callSearch();
        }
    }
    function speekForSearch() {
      $(".searchbox").val('');
      runSpeechRecognition();
      // $(".searchbox").val('load');
      // callSearch("search");
    }
    function callReset() {
      $( ".acuracy_confidence" ).html("");
        $(".searchbox").val('');
        $(".container-fluid").show(200);
        $(".container-fluid-ajax").hide(200);
    }
    function callSearch() {
      if($(".searchbox").val() !=="" && $(".searchbox").val() !== undefined) {
        var subject =  $("#subject-link").val() !== "" ? $("#subject-link").val() : "java-script";
        // alert(subject);

        $(".container-fluid").hide(200);
        $(".container-fluid-ajax").show(200);
        $.ajax({
          type: 'POST',
          url: "results.php",
          data: {subject: subject, search: $(".searchbox").val()},
          dataType: "text",
          success: function(resultData) {
              if(resultData !== undefined) {
                $(".container-fluid").hide(200);
                $(".container-fluid-ajax").show(200);
                $(".container-fluid-ajax").html('');
                // console.log("getResults111--", resultData);
                $(".container-fluid-ajax").html(resultData);
              }
            },
            error: function (err) {
            // check the err for error details
              alert("Error Response");
              console.log(err);

            }
          });
          // console.log("getResults--", getResults);
          // getResults.error(function() { alert("Something went wrong"); });
      }
    }
    function runSpeechRecognition() {
		        // get output div reference
		        var output = document.getElementById("output");
		        // get action element reference
		        var action = document.getElementById("action");
                // new speech recognition object
                var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
                var recognition = new SpeechRecognition();
            
                // This runs when the speech recognition service starts
                recognition.onstart = function() {
                    // action.innerHTML = "<small>listening..</small>";
                    $(".action_output").show();
                    $( ".speeker" ).hide();
                    action.innerHTML =  "<img src='speeking.gif' class='speeking' style='width: 40px;height: 30px;'/>";
                };
                
                recognition.onspeechend = function() {
                    // action.innerHTML = "<small>stopped</small>";
                    $(".action_output").hide();
                    $( ".speeker" ).show();
                    $( ".speeking" ).hide();
                    recognition.stop();
                }
              
                // This runs when the speech recognition service returns result
                recognition.onresult = function(event) {
                    var transcript = event.results[0][0].transcript;
                    var confidence = event.results[0][0].confidence;
                    // output.innerHTML = "<b>Text:</b> " + transcript + "<br/> <b>Confidence:</b> " + (confidence*100).toFixed(1)+"%";
                    output.classList.remove("hide");
                    
                    $( ".acuracy_confidence" ).html("");
                    $( ".searchbox" ).before("<div style='color:#ccc; padding-top: 0.8em;font-size: 10px;' class='acuracy_confidence'>"+(confidence*100).toFixed(1)+"%"+"</div>");
                    $( ".acuracy_confidence" ).fadeOut().fadeIn();
                    $(".searchbox").val('');
                    $(".searchbox").val(transcript);
                    callSearch(); // auto searching by voice
                };
              
                 // start recognition
                 recognition.start();
	        }
   
  </script>

</body>

</html>
<style>
  .topic-chip-container {
    display: inline-flex;
    flex-direction: row;
  }

  .topic-chip,
  .topic-chip-selected {
    display: inline-flex;
    flex-direction: row;
    border: none;
    cursor: pointer;
    height: 34px;
    outline: none;
    padding-left: 10px;
    padding-right: 10px;
    font-size: 14px;
    color: #333;
    white-space: nowrap;
    align-items: center;
    border-radius: 20px;
    vertical-align: middle;
    text-decoration: none;
    justify-content: center;
    box-shadow: 0 2px 1px -1px #d3d3d3;
  }

  .topic-chip {
    margin-bottom: 5px;
   /* margin-top: 5px; */
   /* margin-right: 7px; */
    background-color: rgb(248,249,250);
  }

  .hovered {
    transition: .3s;
  }
  .answers {
      display:none;
      border-radius: 5px;
      font-size:12px;
      font-weight: 300;
      background: #F5F5F5;
      border: 1px solid #ccc;
      padding-left: 4px;
      /* padding: 9.5px;
      margin: 0 0 10px;
      font-size: 13px;
      line-height: 1.42857143;
      color: #333;
      word-break: break-all;
      word-wrap: break-word;
      background-color: #f5f5f5;
      border: 1px solid #ccc;
      border-radius: 4px; */
      
  }
  .list-group-item {
    padding: 0.25rem .75rem;
  }
  .navbar {
    /* padding: .5rem 1rem; */
    padding: 2px;
    }
    .navbar-expand-lg .navbar-nav .nav-link {
        padding-right: 0.4rem;
        padding-left: .4rem;
    }
    .closebtn {
        display:none;
        float:right;
        cursor:pointer;
        color: red;
        font-size: 0.9rem;
        margin-top: 6px;
        margin-left:4px;
        font-size:18px;
    }
    
    /* toogle menu */

#menu-toggle {
    width: 33px;
    /* height: 30px; */
    /* margin: 0px auto; */
    background: #ccc;
}

#menu-toggle div {
  width: 100%;
  height: 5px;
  background: white;
  margin: 4px auto;
  transition: all 0.3s;
  backface-visibility: hidden;
}

#menu-toggle.on .one {
  transform: rotate(45deg) translate(5px, 5px);
}

#menu-toggle.on .two {
  opacity: 0;
}

#menu-toggle.on .three {
  transform: rotate(-45deg) translate(7px, -8px);
}

/* toggle menu end */
.header-priority {
	border: 0px solid red;
    padding: 7px 0px 4px 0px;
	  font-style: italic;
    color: lightblue;
}
.bi {
    display: inline-block;
    vertical-align: -.82em;
    cursor: pointer;
}
</style>