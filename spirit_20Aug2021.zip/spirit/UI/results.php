<?php
// Include config file
require_once "../config.php";
require_once "../subjects.php";
// print_r($_REQUEST);
// Attempt select query execution
if($_REQUEST && $_REQUEST['subject']) {
$cond = " WHERE subject = '".$_REQUEST['subject']."' ";

  if($_REQUEST && $_REQUEST['search']) {
  $cond .= " AND (question LIKE '%".$_REQUEST['search']."%' OR description LIKE '%".$_REQUEST['search']."%' OR metainfo LIKE '%".$_REQUEST['search']."%') ";
  }
} else {
  $cond = '';
}

$sql = "SELECT * FROM qa $cond  ORDER BY FIELD(priority, 'basic', 'advanced', 'repeated'), order_by ASC";
// echo "sql query " . $sql;
?>
<!-- externl stuff -->
<div class="px-3 py-3">
            <?php 
			$priorityArr= [];
            if($result = mysqli_query($link, $sql)){
                while($row = mysqli_fetch_array($result)){
                    // $subject = "Dashboard";
            ?>
		 <?php 
		 if (!in_array($row['priority'], $priorityArr)) {
		?>
		 <div class="header-priority"><h5> <?php  echo ucfirst($row['priority']); ?></h5></div>
		 <?php
			$priorityArr[] = $row['priority'];
		 }
		 ?>
          <div class="topic-chip-container questions questions-<?php echo $row['subject']; ?>"> 
          <a class="no-link" title="<?php echo $row['metainfo'] ? $row['metainfo'] : $row['question']; ?>"
              alt="<?php echo $row['question']; ?>">
              <div class="closebtn cls-<?php echo $row['id'];?>" onClick="closeDescription('<?php echo $row['id'];?>')" >&#10005;</div>

              <div class="topic-chip hovered" onClick="showDescription('<?php echo $row['id'];?>')">
                <div class="justify-content-center align-self-center">
                  <span >&nbsp;&nbsp;<?php echo $row['question']; ?></span>
                  <!-- <span
                    class="small text-muted">&nbsp;&nbsp;45&nbsp;&nbsp;</span> -->
                </div>
              </div>
            </a>
        </div>
            <div class="answers answer-<?php echo $row['id'];?>" ><b>&nbsp;&nbsp;<?php echo $row['description']; ?></b></div>
            <?php } } ?>
        </div>
        <!-- external stuff -->