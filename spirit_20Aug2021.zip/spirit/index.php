<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
        .wrapper{
            width: 850px
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            -moz-tab-size: 4;
            tab-size: 4;
        }
    </style>
</head>
<body>
<?php 
error_reporting(error_reporting() & ~E_NOTICE);
    $input_subject = "";
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $input_subject = trim($_POST["subject"]) ;
        header("location: index.php?subject=". str_replace(' ', '-', strtolower($input_subject)));
        exit();
    }
    ?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div>
                    <div class="page-header clearfix">
                   
                        <div  class="col-md-2" >
                            <h2 class="pull-left">QA Details</h2>
                        </div>
                        
                            <?php 
                            require_once "subjects.php";
                            $subjects = array_merge($subjects_frontend,$subjects)
                            ?>
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div  class="col-md-2" >
                                <div>         
                                    <select name="subject" id="subject" class="form-control" style="width:200px;">
                                        <option value="">All</option>
                                        <?php for ($x = 0; $x < count($subjects); $x++) { 
                                            $val =  str_replace(' ', '-', strtolower($subjects_frontend[$x])); 
                                            ?>
                                        <option value="<?php echo $val; ?>" <?php echo $val == $_GET["subject"] ? 'selected="selected"': ''; ?>><?php echo $subjects[$x]; ?></option>
                                        <?php } ?>
                                    </select>
                                </div> 
                                </div>
                                <div  class="col-md-1" >
                                <input type="submit" class="btn btn-primary" value="Submit">
                                </div>
                            </form>
                        
                        <div class="col-md-6"  >
                            <a href="./dragndrop/index.php<?php echo !empty($_GET["subject"]) ? '?subject='.$_GET["subject"] : ''; ?>" class="btn btn-info pull-right"target="_new">Change Order</a>
                        </div>
                        <div class="col-md-1"  >
                            <a href="create.php" class="btn btn-success pull-right">Add New</a>
                        </div>                        
                 </div>
                <div class="col-md-12">
                    <?php
                    // Include config file
                    require_once "config.php";

                    // Attempt select query execution
                    $cond = '';
                    if(!empty($_REQUEST["subject"])) {
                        $cond .= " WHERE subject = '". trim($_REQUEST["subject"])."'";
                    }
                    $sql = "SELECT * FROM qa $cond ORDER BY id DESC";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            //echo "<table class='table table-bordered table-striped'>";
                            echo "<table id='dtBasicExample' class='table table-striped table-bordered table-sm' cellspacing='0' width='100%'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Subject</th>";
                                        echo "<th>Question</th>";
                                        echo "<th>Description</th>";
                                        echo "<th>Meta Info</th>";
                                        echo "<th>Action</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['subject'] . "</td>";
                                        echo "<td>" . $row['question'] . "</td>";
                                        echo "<td>" . $row['description'] . "</td>";
                                        echo "<td>" . $row['metainfo'] . "</td>";
                                        echo "<td>";
                                            echo "<a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='update.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            echo "<a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?>
                </div>
                </div>
            </div>        
        </div>
    </div>

            <script type="text/javascript">
        $(document).ready(function(){
            // $('[data-toggle="tooltip"]').tooltip();   
            // Basic example

            $('#dtBasicExample').DataTable({
            "searching": true // false to disable search (or any other option)
            });

        });
    </script>


</body>
</html>