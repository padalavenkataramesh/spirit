<?php 
include_once("db_connect.php");
include('header.php');
?>
<title>Drag and Drop</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script type="text/javascript" src="reorder.js"></script>
<link rel="stylesheet" href="style.css">
<?php //include('container.php');?>
<div class="container">
<?php 
require_once "../subjects.php";
$subjects = array_merge($subjects_frontend,$subjects)
?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div  class="col-md-2" >
                                <div>         
                                    <select name="subject" id="subject" class="form-control" style="width:200px;">
                                        <option value="">All</option>
                                        <?php for ($x = 0; $x < count($subjects); $x++) { 
                                            $val =  str_replace(' ', '-', strtolower($subjects_frontend[$x])); 
                                            ?>
                                        <option value="<?php echo $val; ?>" <?php echo $val == $_GET["subject"] ? 'selected="selected"': ''; ?>><?php echo $subjects[$x]; ?></option>
                                        <?php } ?>
                                    </select>
                                </div> 
                                </div>
                                <div  class="col-md-1" >
                                <input type="submit" class="btn btn-primary" value="Submit">
                                </div>
							</form>
							
	<h2>Example: Drag and Drop By Javascript</h2>
	
	<div>		
		<div class="gallery">
			<ul class="reorder-gallery">
			<?php 			
			$sql_query = "SELECT id, question FROM qa ORDER BY order_by";
			$resultset = mysqli_query($conn, $sql_query) or die("database error:". mysqli_error($conn));
			$data_records = array();
			while( $row = mysqli_fetch_assoc($resultset)) {				
			?>
				<li id="<?php echo $row['id']; ?>" class="ui-sortable-handle"><a href="javascript:void(0);">
				<?php echo $row['question']; ?></a></li>
			<?php } ?>
			</ul>
		</div>
	</div>
	
	<div>
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="../index.php<?php echo !empty($_GET["subject"]) ? '?subject='.$_GET["subject"] : ''; ?>" title="">Back to Tutorial</a>			
	</div>		
</div>
<?php include('footer.php');?>


